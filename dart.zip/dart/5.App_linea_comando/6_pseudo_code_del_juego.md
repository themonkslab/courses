# _Pseudo code_ para el juego

Como venimos haciendo, escribamos lo que necesitamos hacer de forma coloquial en nuestro propio código  según los requerimientos:

```dart
void main() {
    print('Hello world!');


    //  Pseudo code
    //  
    //  Mientras que sea verdad
    //      Mostrar el prompt al usuario
    //      Leer su respuesta desde la consola
    //      Si el input es válido ('r', 'p', 's')
    //          Ejecutar opción random de computadora
    //          Comparar ese movimiento con el del usuario
    //          Mostrar el resultado
    //      Si el input es 'q'
    //          Salir del programa
    //      Si el input es otra tecla
    //          Mostrar 'Invalid input'
}
```
