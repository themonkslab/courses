# Introducción

Ya tienen un pantallazo de los _features_ o características básicas de Dart. Es hora de empezar a resolver problemas cada vez más interesantes y para ello, ya no podremos utilizar Dartpad todo el tiempo sino herramientas mucho más poderosas que los harán muy felices! 😁

En esta sección vamos a instalar el Dart SDK y VSCode y a programar nuestro primer juego para línea de comando!
