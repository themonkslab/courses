# Crear, correr y debuggear en VS Code

Qué es VS Code? Es __nuestro editor de código favorito__ ya que es sumamente __popular__, lo que significa que __evoluciona constanmente__ y por ellos tiene un __montón de plugins y extensiones__ (agregados al programa para ofrecer funcionalidad) y es __super liviano__!

Vamos a instalarlo:

TP Nahuel > instalación + extensiones que Mau pase
