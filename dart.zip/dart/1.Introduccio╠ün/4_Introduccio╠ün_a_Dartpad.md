# Introducción a Dartpad

@Mau Di Bert

Dart viene con una herramienta para rápidamente escribir código Dart online y ver el _output_ (la salida, lo que se ve), de dicho código. Esa herramienta se llama [Dartpad](https://dartpad.dev) y es totalmente gratuita. Lo vamos a utilizar para las primeras partes de este curso.

![Dartpad basics](https://raw.githubusercontent.com/themonkslab/courses/main/dart/1.Introducci%C3%B3n/4.1_dartpad_basics.png)

![Dartpad basics errors and rest](https://raw.githubusercontent.com/themonkslab/courses/main/dart/1.Introducci%C3%B3n/4.2_dartpad_basics_errors_and_rest.png)
