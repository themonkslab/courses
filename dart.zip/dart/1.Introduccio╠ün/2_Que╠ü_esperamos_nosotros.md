# Qué esperamos nosotros

En este curso esperamos poder introducirlos a ustedes a la programación pero también a una forma distinta de hacer las cosas, pensando en sus consecuencias y construyendo desde ellas.

Esperamos sea la piedra inicial de la escuela que soñamos, una que abra las puertas a todo aquél que quiera aprender, que estimule a los que no y que conecte el ámbito profesional con el aprendizaje. Una forma de aprender, enseñar y vivir que nos habitúe a dar antes de recibir, que nos enseñe formas de expresarnos, de comunicarnos.

Esperamos sea un lugar para permitirnos ser quienes somos y más aun, quienes imaginamos queremos ser.
