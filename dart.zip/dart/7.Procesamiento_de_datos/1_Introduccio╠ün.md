# Introducción

En esta sección __vamos a__ utilizar Dart para __procesar datos__ provenientes de un archivo `.csv`, que vendría a ser un archivo de texto separado por comas o _comma separated values_, que nos permite representar datos producidos por lo general, desde una planilla de cálculos. Les voy a dejar un ejemplo para que trabajemos, aunque crear sus propios archivos desde planillas es bien sencillo, simplemente exportando su documento como `.csv`.

Intentaremos parsear argumentos de la línea de comandos, leer el archivo línea a línea, procesarlo, y más!
