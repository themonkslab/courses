# Sistema de tipado

@Mau Di Bert

En esta sección vamos a ver qué es un _type system_ y entender:

- Lenguajes dinámicos y estáticos
- Inferencia de tipo
- estas palabras clave: `var`, `final`, `const`, `dynamic`
