# Dart nivel básico

@Mau Di Bert

Esta sección es para incluso quienes jamás vieron una línea de código. Vamos a ver:

- variables y tipos básicos
- declaración, inicialización y asignación
- strings y tipos numéricos
- operadores

Al final, vas a poder escribir programas simples en Dart!
