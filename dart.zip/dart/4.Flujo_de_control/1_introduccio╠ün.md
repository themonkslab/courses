# Flujo de control

@Mau Di Bert

En esta sección veremos qué es el _control flow_ o cómo escribir __código que tomará decisiones basado en ciertas condiciones__. Esto se va poniendo más interesante! Aprenderemos:

- _if/else statements_
- _while/for loops_
- _switch statements_
- _enumerations_
